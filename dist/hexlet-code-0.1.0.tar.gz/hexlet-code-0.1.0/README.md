### Hexlet tests and linter status:
[![Actions Status](https://github.com/Grep27/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/Grep27/python-project-lvl1/actions)