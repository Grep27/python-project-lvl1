### Hexlet tests and linter status:
[![Actions Status](https://github.com/Grep27/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/Grep27/python-project-lvl1/actions)
<a href="https://codeclimate.com/github/codeclimate/codeclimate/maintainability"><img src="https://api.codeclimate.com/v1/badges/a99a88d28ad37a79dbf6/maintainability" /></a>
![example workflow](https://github.com/Grep27/python-project-lvl1/actions/workflows/lint_test.yml/badge.svg)
