#!/usr/bin/env python
from barin_games import cli
def main():
    print('Welcome to the Brain Games!')
if __name__ == '__main__':
    main()

cli.welcome_user()
